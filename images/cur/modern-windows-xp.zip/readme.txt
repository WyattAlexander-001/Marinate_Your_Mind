﻿=== Modern Windows XP Cursor Set ===

By: Virum64 (http://www.rw-designer.com/user/30267) virum64@gmail.com

Download: http://www.rw-designer.com/cursor-set/modern-windows-xp

Author's description:

[[image:rsrc/madeinfrance.png]]

I just added a little bevel effect and a shadow to the default Windows XP cursors. I also animated the hourglasses in the "Working in Background" and the "Busy" cursors.

Visit my [[image:rsrc/facebook_button.png]] page  [https://www.facebook.com/Virum64cursordesigner/ here].

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.